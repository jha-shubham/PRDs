This file is intentionally unsupported by the TCG-PRD ingest path.
It exists only to exercise the 1.4 Unsupported Document Type code path in cucumber tests.
